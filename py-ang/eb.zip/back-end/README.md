# Introduction 
We need to replace the Power Module Wizard that was built by Transim with our own home-brew system.
We have a web server, a database, and some SIMPLIS simulation modules.
We are using python for the web server, sqlite3 as the database, and a fake SIMPLIS (for now).

# Getting Started
You can use this proof-of-concept to explore the Power Module Wizard API (pmw-api.txt).
1.	Installation process - create C:\pmw and put all the files in this repo into that directory.
2.	Make sure you have a recent version of python on your machine
3.	The latest version of the proof-of-concept can always be found in the repository.
4.	See pmw-api.txt for a description of all the services provided by server.py.

# Build and Test
There is no building involved as everything is a Python program. 
To test the API, start up the server with "python server.py".
You will see that it listens on http://localhost:8080.  
Access the test web page with http://localhost:8080/test with your browser.
You can use sqlite3 to inspect pmw.db, the database file.  

# Contribute
Talk to Mark Johnson (mark.a.johnson@omnionpower.com) about changes. 
