# Python replacement for pol.xlsx spreadsheet
# three calculations: setting trim resistors, setting trim voltages, checking the voltage settings
#
# see pmw-api.txt for details on inputs and outputs
# see pol.xlsx for all the formulas involved, the equations are taken directly from the spreadsheet
#
# Mark Johnson, February 2026

import sys
import json
import pol_data

def find_part(part):
    # search the parts data for the object that matches
    for p in pol_data.parts:
        if part in p.name:
            return p
    return None

def volt(part, vout, rg, volow, vohigh):
    r = {
        "success": 0,
        "error": "",
        "vglow": 0,
        "vghigh": 0,
        "vgnom": 0,
        "rtrim": 0
    }
    p = find_part(part)
    if p is None:
        r["error"] = "part '%s' not found" % part
        return r
    # set the input variables
    try:
        C24 = float(vout)
        G24 = float(rg)
        G26 = float(volow)
        G28 = float(vohigh)
    except:
        r["error"] = "inputs are not numbers"
        return r
    p.fixTJT(C24)
    # do the calculations
    I8 = p.num
    I11 = p.r1
    I12 = p.r2
    I13 = p.vref
    C28 = 115000 if (I8 == 48 or I8 == 49) else ((I11*I13)/(C24-I13))
    D50 = I13
    I24 = (G26-D50)/I11
    K24 = D50-(I24*I12)
    G30 = K24+(G24*((K24/C28)-I24))
    I26 = (G28-D50)/I11
    K26 = D50-(I26*I12)
    G32 = K26+(G24*((K26/C28)-I26))
    I28 = (C24-D50)/I11
    K28 = D50-(I28*I12)
    G34 = K28+(G24*((K28/C28)-I28))
    # retrieve the results
    r["vglow"] = G30
    r["vghigh"] = G32
    r["vgnom"] = G34
    r["rtrim"] = C28
    r["success"] = 1
    return r

def trim(part, vout, margin):
    r = {
        "success": 0,
        "error": "",
        "rtrim": 0,
        "rup": 0,
        "rdown": 0,
    }
    p = find_part(part)
    if p is None:
        r["error"] = "part '%s' not found" % part
        return r
    # set the input variables
    try:
        C24 = float(vout)
        C26 = float(margin)
    except:
        r["error"] = "vout and margin are not numbers"
        return r
    p.fixTJT(C24)
    # do the calculations
    I8 = p.num
    I11 = p.r1
    I12 = p.r2
    I13 = p.vref
    C28 = 115000 if (I8==48 or I8==49) else ((I11*I13)/(C24-I13))
    I30 = (I11*I13)/((C24*(1+(0.01*C26)))-I13)
    C30 = "n/a" if (I8==44 or I8==45) else (C28*I30/(C28-I30))
    I32 = ((C24*C28*(1-(0.01*C26)))-(I13*C28))/I13
    C32 = "n/a" if (I8==44 or I8==45) else ((I32*I11)/(I11-I32))
    # retrieve the results
    r["rtrim"] = C28
    r["rup"] = C30
    r["rdown"] = C32
    r["success"] = 1
    return r

def vset(part, vout, rtrim, rup, rdown, tolpct):
    r = {
        "success": 0,
        "error": "",
        "rmin": 0,
        "rmax": 0,
        "vout": 0,
        "vup": 0,
        "vdown": 0,
        "errup": 0,
        "errdown": 0
    }
    p = find_part(part)
    if p is None:
        r["error"] = "part '%s' not found" % part
        return r
    # set the input variables
    try:
        C24 = float(vout)
        C36 = float(rtrim)
        C40 = float(rup)
        C44 = float(rdown)
        F52 = float(tolpct)/100
    except:
        r["error"] = "inputs are not numbers"
        return r
    p.fixTJT(C24)
    # do the calculations
    I8 = p.num
    I11 = p.r1
    I13 = p.vref
    H49 = 25
    I49 = 30
    I50 = 30
    D50 = I13
    F50 = 0.01
    F51 = p.ruptol
    C50 = D50*(1-F50)
    E50 = D50*(1+F50)
    H50 = 100 if (F52==0.01) else 25
    D51 = I11
    D52 = C36
    C52 = D52*(1-F52-(H50*I50/1000000))
    D54 = C24 if (I8==44 or I8==45) else (D50*((D51+D52)/D52))
    E51 = D51*(1+F51+(H49*I49/1000000))
    C38 = I13*(I11+C36)/C36
    if I8 == 17: E53 = 0.01
    elif I8 == 24: E53 = 0.002
    elif C38 >= 2.5: E53 = (C38*0.004)
    else: E53 = 0.004
    E54 = p.vomax(E50, E51, C52, E53)
    E52 = D52*(1+F52+(H50*I50/1000000))
    C51 = D51*(1-F51-(H49*I49/1000000))
    if I8 == 17: C53 = -0.01
    elif I8 == 24: C53 = -0.002
    elif C38 >= 2.5: C53 = (-C38*0.004)
    else: C53 = -0.004
    C54 = p.vomin(C50, E52, C51, C53)
    E55 = ((E54-D54)/D54)
    C55 = ((C54-D54)/D54)
    # gather up the outputs
    r["rmin"] = C52
    r["rmax"] = E52
    r["vout"] = D54
    r["vup"] = E54
    r["vdown"] = C54
    r["errup"] = E55
    r["errdown"] = C55
    r["success"] = 1
    return r
    
if __name__ == '__main__':
    n = len(sys.argv)
    av = sys.argv
    if n > 6 and "vo" in av[1]:
        print(volt(av[2], av[3], av[4], av[5], av[6]))
    elif n > 4 and "tr" in av[1]:
        print(trim(av[2], av[3], av[4]))
    elif n > 5 and "vs" in av[1]:
        print(vset(av[2], av[3], av[4], av[5]))
    else:
        print("usage: pol trim part vout margin%")
        print("       pol volt part vout rg volow vohigh")
        print("       pol vset part vout rtrim rup rdown tolerance%")
        print("examples:")
        print("pol trim APXS002 1.5 5")
        print(trim("APXS002", 1.5, 5))
        print("pol volt APXS002 1.5 30000 20 32")
        print(volt("APXS002", 1.5, 30000, 20, 32))
        print("pol vset APXS002 1.5 6667 80000 110000 0.1")
        print(vset("APXS002", 1.5, 6667, 80000, 110000, 0.1))
        
