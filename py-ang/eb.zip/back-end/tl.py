# a python implementation of the tunable loop spreadsheet

import sys
import json
import tl_data as tld


low_range = [100000, 99.99, 74.99, 59.99, 49.999, 39.999, 29.999, 24.999, 19.999, 14.999, 9.999 ]
high_range = [100000, 499.99, 399.99, 299.99, 249.99, 199.99, 149.99, 124.99, 99.99, 74.99, 49.99 ]

def find_part(part):
    for p in tld.parts:
        if part in p.name:
            return p
    return None

def calc(part, vin, vout, dImax, dVmax):
    r = {
        "success": 0,
        "error": "",
        "vinMin": 0,
        "vinMax": 0,
        "ioMax": 0,
        "voMax": 0,
        "dropdown": [],
        "labels": [],
        "values": []
    }
    p = find_part(part)
    if p is None:
        r["error"] = "part '%s' not found" % part
    else:
        # set the limit data
        p.preset(vin, vout)
        r["vinMin"] = p.vmin
        r["vinMax"] = p.vmax
        r["ioMax"] = p.iomax
        r["voMax"] = p.vomax
        dd = []
        for d in p.iosteps:
            dd.append("%dmV" % d)
        r["dropdown"] = dd
        # set the inputs
        tlD5 = p.name
        tlD6 = vin
        tlD7 = vout
        tlD8 = dImax
        tlD9 = dVmax
        # do all the calculations
        tlC11 = p.l1
        tlC12 = p.l2
        tlC13 = p.l3
        tlC14 = p.l4
        D69 = p.v1
        D70 = p.v2
        D71 = p.v3
        D76 = p.volow
        D77 = p.vomax
        D79 = p.vmin
        D80 = p.vmax
        D82 = 0
        D83 = p.iomax
        D104 = p.vuse
        D106 = tlD6
        D107 = tlD7
        D108 = tlD8
        D109 = float(tlD9.replace("mV", ""))
        D110 = 2 * D108 / p.iomax
        D111 = D109 / D110
        D113 = p.num
        if D113 < 50:
            D112 = match_smallest(D111, low_range)+1
        else:
            D112 = match_smallest(D111, high_range)+1
        D114 = (1 if D104 == D69 else (2 if D104 == D70 else 3))
        D115 = p.offset # row number in details data table
        D119 = tld.details[D115][D112]
        D120 = tld.details[D115+1][D112]
        D121 = tld.details[D115+2][D112]
        D122 = tld.details[D115+3][D112]
        D124 = D106 < D79 or D106 > D80
        D125 = D107 < D76 or D107 > D77
        D126 = D108 < D82 or D108 > D83
        D127 = D124 or D125 or D126
        tlD11 = None if isErr(D119) or D127 else D119
        tlD12 = None if isErr(D120) or D127 else D120
        tlD13 = None if isErr(D121) or D127 else D121
        tlD14 = None if isErr(D122) or D127 else D122
        # set the outputs
        r["labels"] = [ tlC11, tlC12, tlC13, tlC14 ]
        r["values"] = [ tlD11, tlD12, tlD13, tlD14 ]
        if D127:
            err = []
            if D124: err.append("input voltage out of range")
            if D125: err.append("output voltage out of range")
            if D125: err.append("current out of range")
            r["error"] = ", ".join(err)
        else:
            r["success"] = 1
    return r

def isErr(s):
    return isinstance(s, str) and s[0] == "#"

def match_smallest(value, value_list):
    i = len(value_list)-1
    while i > 0:
        if value <= value_list[i]:
            break
        i -= 1
    return i+1

if __name__ == '__main__':
    if len(sys.argv) == 6:
        av = sys.argv
        x = calc(av[1], float(av[2]), float(av[3]), float(av[4]), av[5])
    else:
        print("usage: tl part Vin Vout dImax dVmax")
        print("example: tl APXS002 12 5 1 100mV")
        x = calc("APXS002", 12, 5, 1, "100mV")
    print(json.dumps(x, indent=2))
