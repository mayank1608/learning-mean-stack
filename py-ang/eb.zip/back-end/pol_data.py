
class Part:
    def __init__(self, name, num, r1, r2, vref, vreftol, ruptol, tvomax):
        self.name = name
        self.num = num
        self.r1 = r1
        self.r2 = r2
        self.vref = vref
        self.vreftol = vreftol
        self.ruptol = ruptol
        self.tvomax = tvomax

    def vomax(self, E50, E51, C52, E53):
        if self.tvomax == 0:
            return E50*((E51+C52)/C52)+E53
        elif self.tvomax == 1:
            return (1.005*E50*((E51+C52)/C52))+E53
        else:
            return E50+0.0005

    def vomin(self, C50, E52, C51, C53):
        if self.tvomax == 0:
            return C50*((E52+C51)/E52)+C53
        elif self.tvomax == 1:
            return (0.995*C50*((E52+C51)/E52))+C53
        else:
            return C50-0.005

    def fixTJT(self, C24):
        if self.tvomax == 2:
            self.vref = C25
            self.r1 = tjt_lookup(C24)


parts = [
  Part('APXS002 (2A PicoTLynx(tm))', 1, 10000, 0, 0.600000, 0.010000, 0.010000, 0),
  Part('APTH003 / APXH003 (3A PicoTLynx(tm))', 2, 2000, 0, 0.600000, 0.016666, 0.001000, 0),
  Part('APTS003 / APXS003 (12Vin / 3A PicoTLynx(tm))', 3, 10000, 0, 0.591000, 0.010150, 0.001000, 0),
  Part('APTH006 / APXH006 (6A PicoTLynx(tm))', 4, 2000, 0, 0.600000, 0.016666, 0.001000, 0),
  Part('APTS006 / APXS006 (12Vin / 6A PicoTLynx(tm))', 5, 10000, 0, 0.591000, 0.010150, 0.001000, 0),
  Part('APTH012 / APXH012 (12A MicroTLynx(tm))', 6, 2000, 0, 0.600000, 0.016666, 0.001000, 0),
  Part('APTS012 (12Vin / 12A MicroTLynx(tm))', 7, 10000, 0, 0.690000, 0.010145, 0.001000, 0),
  Part('PVX003 (12Vin / 3A Analog PicoDLynxTM)', 8, 20000, 0, 0.600000, 0.010000, 0.001000, 0),
  Part('PDT003 (12Vin / 3A Digital PicoDLynxTM)', 9, 20000, 0, 0.600000, 0.010000, 0.001000, 1),
  Part('PVX006 (12Vin / 6A Analog PicoDLynxTM)', 10, 20000, 0, 0.600000, 0.010000, 0.001000, 0),
  Part('PDT006 (12Vin / 6A Digital PicoDLynxTM)', 11, 20000, 0, 0.600000, 0.010000, 0.001000, 1),
  Part('PVX012 (12Vin / 12A Analog PicoDLynxTM)', 12, 20000, 0, 0.600000, 0.010000, 0.001000, 0),
  Part('PDT012 (12Vin / 12A Digital PicoDLynxTM)', 13, 20000, 0, 0.600000, 0.010000, 0.001000, 1),
  Part('PNDT003 (12Vin/3A SlimLynxTM)', 14, 20000, 0, 0.600000, 0.010000, 0.001000, 1),
  Part('PNDT006 (12Vin/6A SlimLynxTM)', 15, 20000, 0, 0.600000, 0.010000, 0.001000, 1),
  Part('PNDT012 (12Vin/12A SlimLynxTM)', 16, 20000, 0, 0.600000, 0.010000, 0.001000, 1),
  Part('ULDT006/UNDT006 (12Vin/6A SlimLynxTM)', 17, 20000, 0, 0.600000, 0.010000, 0.001000, 1),
  Part('ULDT012/UNDT012 (12Vin/12A SlimLynxTM)', 18, 20000, 0, 0.600000, 0.010000, 0.001000, 1),
  Part('UDXS0606 (12Vin/6A+6A Dual DLynxTM)', 19, 20000, 0, 0.600000, 0.010000, 0.001000, 1),
  Part('UDXS1212 (12Vin/12A+12A Dual DLynxTM)', 20, 20000, 0, 0.600000, 0.010000, 0.001000, 1),
  Part('UVT020/UDT020 (12Vin / 20A MicroDLynxTM)', 21, 20000, 0, 0.600000, 0.010000, 0.001000, 1),
  Part('APTH020 / APXH020 (20A TLynx(tm))', 22, 2000, 0, 0.600000, 0.016666, 0.001000, 0),
  Part('APTS020 (12Vin / 20A TLynx(tm))', 23, 10000, 0, 0.690000, 0.010145, 0.001000, 0),
  Part('APTS030 (12Vin / 30A MegaTLynx(tm))', 24, 10000, 0, 0.800000, 0.015000, 0.001000, 0),
  Part('MVT040/MDT040 (12Vin / 40A MegaDLynxTM)', 25, 20000, 0, 0.600000, 0.010000, 0.001000, 1),
  Part('GDT080 (12Vin / 80A GigaDLynxTM)', 26, 2000, 0, 0.600000, 0.010000, 0.001000, 0),
  Part('APTS050 (12Vin / 50A GigaTLynx(tm))', 27, 20000, 0, 0.700000, 0.008571, 0.001000, 0),
  Part('NSR003 (12Vin / 3A Naos Raptor(tm))', 28, 2000, 0, 0.591000, 0.010150, 0.001000, 0),
  Part('NSR006 (12Vin / 6A Naos Raptor(tm))', 29, 2000, 0, 0.591000, 0.010150, 0.001000, 0),
  Part('NQR010/NSR010 (12Vin / 10A Naos Raptor(tm))', 30, 2000, 0, 0.591000, 0.010150, 0.001000, 0),
  Part('NSR020 (12Vin / 20A Naos Raptor(tm))', 31, 2000, 0, 0.591000, 0.010150, 0.001000, 0),
  Part('NSR040 (12Vin / 40A Naos Raptor(tm))', 32, 2000, 0, 0.600000, 0.008000, 0.001000, 0),
  Part('NSR060 (12Vin / 60A Naos Raptor(tm))', 33, 2000, 0, 0.600000, 0.008000, 0.001000, 0),
  Part('APXW003 (9-36Vin / 3A ProLynxTM)', 34, 100000, 0, 0.700000, 0.010000, 0.001000, 0),
  Part('APXW005 (9-36Vin / 5A ProLynxTM)', 35, 100000, 0, 0.700000, 0.010000, 0.001000, 0),
  Part('APXW012 (9-36Vin / 12A ProLynxTM)', 36, 100000, 0, 0.700000, 0.010000, 0.001000, 0),
  Part('ABXS001 (8 - 16Vin/32-54Vout BoostLynxTM)', 37, 200000, 0, 1.200000, 0.010000, 0.010000, 0),
  Part('ABXS002 (8 - 16Vin/16-34Vout BoostLynxTM)', 38, 200000, 0, 1.200000, 0.010000, 0.010000, 0),
  Part('ABXS003 (8 - 16Vin/32-54Vout BoostLynxTM)', 39, 200000, 0, 1.200000, 0.010000, 0.010000, 0),
  Part('ABXS005 (8 - 16Vin/16-34Vout BoostLynxTM)', 40, 200000, 0, 1.200000, 0.010000, 0.010000, 0),
  Part('FKX003 (12Vin / 3A FemtoDlynx IITM)', 41, 20000, 0, 0.600000, 0.010000, 0.001000, 1),
  Part('FKX006 (12Vin / 6A FemtoDlynx IITM)', 42, 20000, 0, 0.600000, 0.010000, 0.001000, 1),
  Part('PJT004 (12Vin / 4A PicoDlynx IITM)', 43, 20000, 0, 0.600000, 0.010000, 0.001000, 1),
  Part('PJT007 (12Vin / 7A PicoDlynx IITM)', 44, 20000, 0, 0.600000, 0.010000, 0.001000, 1),
  Part('PJT014 (12Vin / 14A PicoDlynx IITM)', 45, 20000, 0, 0.600000, 0.010000, 0.001000, 1),
  Part('PJT020 (12Vin / 20A PicoDlynx IITM)', 46, 20000, 0, 0.600000, 0.010000, 0.001000, 1),
  Part('UJT035 (12Vin / 35A MicroDlynx IITM)', 47, 20000, 0, 0.600000, 0.010000, 0.001000, 1),
  Part('TJT/TJX120 (12Vin / 120A TeraDlynx IITM)', 48, 0, 0, 0.000000, 0.010000, 0.001000, 2),
  Part('TJT170 (12Vin / 170A TeraDlynx IITM)', 49, 0, 0, 0.000000, 0.010000, 0.001000, 2),
]

def tjt_lookup(x):
    if x <= 0.100000: return 167
    if x <= 0.120000: return 196
    if x <= 0.140000: return 226
    if x <= 0.160000: return 255
    if x <= 0.180000: return 287
    if x <= 0.200000: return 316
    if x <= 0.220000: return 352
    if x <= 0.240000: return 383
    if x <= 0.260000: return 417
    if x <= 0.280000: return 448
    if x <= 0.300000: return 487
    if x <= 0.320000: return 517
    if x <= 0.340000: return 556
    if x <= 0.360000: return 590
    if x <= 0.380000: return 626
    if x <= 0.400000: return 665
    if x <= 0.420000: return 706
    if x <= 0.440000: return 741
    if x <= 0.460000: return 787
    if x <= 0.480000: return 825
    if x <= 0.500000: return 866
    if x <= 0.520000: return 909
    if x <= 0.540000: return 953
    if x <= 0.560000: return 1000
    if x <= 0.580000: return 1040
    if x <= 0.600000: return 1090
    if x <= 0.620000: return 1140
    if x <= 0.640000: return 1180
    if x <= 0.660000: return 1230
    if x <= 0.680000: return 1290
    if x <= 0.700000: return 1330
    if x <= 0.720000: return 1380
    if x <= 0.740000: return 1470
    if x <= 0.760000: return 1560
    if x <= 0.780000: return 1640
    if x <= 0.800000: return 1740
    if x <= 0.820000: return 1820
    if x <= 0.840000: return 1930
    if x <= 0.860000: return 2030
    if x <= 0.880000: return 2130
    if x <= 0.900000: return 2230
    if x <= 0.920000: return 2340
    if x <= 0.940000: return 2460
    if x <= 0.960000: return 2610
    if x <= 0.980000: return 2710
    if x <= 1.000000: return 2870
    if x <= 1.020000: return 3050
    if x <= 1.040000: return 3240
    if x <= 1.060000: return 3480
    if x <= 1.080000: return 3700
    if x <= 1.100000: return 3920
    if x <= 1.120000: return 4220
    if x <= 1.140000: return 4530
    if x <= 1.160000: return 4990
    if x <= 1.180000: return 5360
    if x <= 1.200000: return 5900
    if x <= 1.220000: return 6420
    if x <= 1.240000: return 6980
    if x <= 1.260000: return 7680
    if x <= 1.280000: return 8450
    if x <= 1.300000: return 9420
    if x <= 1.320000: return 10400
    if x <= 1.340000: return 11700
    if x <= 1.360000: return 13500
    if x <= 1.380000: return 15800
    if x <= 1.400000: return 18900
    if x <= 1.420000: return 23200
    if x <= 1.440000: return 29800
    if x <= 1.460000: return 40200
    if x <= 1.480000: return 60400
    if x <= 1.500000: return 115000
    return 115000

if __name__ == "__main__":
    print(len(parts), "parts")
    p = parts[0]
    print(p.name, p.num, p.tvomax)
    print("tjt_lookup(0.5)", tjt_lookup(0.5))

