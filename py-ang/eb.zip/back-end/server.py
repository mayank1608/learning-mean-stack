# Power Module Wizard proof of concept
# TBD: test all incoming JSON for possible SQL scripting hacks

import sys
import os
import time
import json
import sqlite3
import secrets
import tl
import pol
import analysis
from dotenv import load_dotenv
from bottle import get, post, static_file, request, response, template, run

valid_tokens = {}
token_timeout = (60 * 60 * 8)  # 8 hours worth of seconds

def db_exec(sql):
        "execute the given sql statement on the pmw database, return an array of rows"
        r = []
        try:
                cur = db.cursor()
                res = cur.execute(sql)
                db.commit()
                r = res.fetchall()
                cur.close()
                # print("db:", sql, "=>", r)
        except sqlite3.OperationalError as e:
                print("db fail: sql='%s'\nerr='%s'" % (sql, e))
                r = None
        return r

def log(uid, event):
        "put a log entry into the database"
        print("log", uid, event)
        ts = time.time()
        query = "insert into log (uid, event, ts) values (%d, '%s', %d)" % (uid, event, ts)
        db_exec(query)

def new_token(uid):
        "generate a random number, store in valid tokens with a timestamp"
        token = secrets.token_urlsafe()
        valid_tokens[token] = [ uid, time.time() ];
        return token

def remove_token(uid):
        "remove tokens associated with a user"
        drop = []
        for t in valid_tokens:
                if valid_tokens[t][0] == uid:
                       drop.append(t)
        for t in drop:
                del valid_tokens[t]

def check_token():
        "handle tokens - delete old ones, check request, return uid if good and 0 if bad"
        now = time.time()
        # find the invalid tokens
        invalid = []
        for t in valid_tokens:
                ts = valid_tokens[t][1]
                if now > (ts + token_timeout):
                        print("token", t, "has timed out")
                        invalid.append(t)
        # remove the invalid tokens
        for key in invalid:
                del valid_tokens[key]
        # get the token in the header
        auth = request.get_header("Authorization")
        if auth is None or len(auth) == 0:
                print("check_token - no token")
                response.status = 401
                return 0
        token = auth[7:]
        if token not in valid_tokens:
                print("check_token - invalid token %s" % token)
                response.status = 401
                return 0
        return valid_tokens[token][0]

def check_user(email):
        "see if the user's email is in the database"
        rows = db_exec("select uid from users where email='%s'" % email)
        if rows is None or len(rows) == 0: return 0
        return int(rows[0][0])

def check_pwd(uid, pwd):
        "does the given password match the user's password; an empty password never matches"
        rows = db_exec("select pwd from users where uid=%d" % uid)
        if rows is None or len(rows) == 0 or rows[0][0] == "": return False
        pwd_hash = int(rows[0][0])
        if pwd_hash < 0:
                # temporary password, remove it from the database
                query = "update users set pwd='' where uid=%d" % uid
                db_exec(query)
                pwd_hash = abs(pwd_hash)
        return pwd == pwd_hash

def check_admin(uid):
        "is the given uid an admin user"
        rows = db_exec("select adm from users where uid=%d" % uid)
        if rows is None or len(rows) == 0: return 0
        return int(rows[0][0])

def check_args(*args):
        "confirm the needed arguments are contained in the JSON request"
        r = ""
        for arg in args:
                if arg not in request.json:
                        r += arg + " "
        if len(r) == 0: return None
        return "missing: " + r

def username(uid):
        "convert a user ID into their email"
        try:
                userid = int(uid)
        except:
                return ""
        query = "select email from users where uid=%d" % userid
        rows = db_exec(query)
        if rows is None: return ""
        return rows[0][0]

def hash(s):
        "convert a password into a hash value (so we don't store passwords in the database)"
        # TBD: there are more sophisticated ways of doing this...
        r = 0
        for c in s:
                r += ord(c)
        # print(s, "hashes to", r)
        return r

def pack(x):
        "pack numbers into a string easily searched with SQL like; [2,3] becomes :2:3:"
        r = ""
        if len(x) > 0:
                r = ":" + ":".join(x) + ":"
        print("pack", x, r)
        return r

def unpack(s):
        "unpack a string of :2:3: into [ 2, 3 ]"
        r = []
        if isinstance(s, str) and len(s) > 0 and s[0] == ":":
                r = s[1:-1].split(":")
        print("unpack", s, r)
        return r

def lead_central(uid):
        "generate the Lead Central XML and mail it to them"
        query = "select first,last,email,company,phone,postal,country,title from users where uid=%d" % uid
        rows = db_exec(query)
        if rows is None or len(rows) == 0: return
        dest = "powerconversion@growthpoint-inc.net"
        subj = "New Power Module Wizard Login"
        row = rows[0]
        xml = "<xml>\n"
        xml += "  <FirstName>%s</FirstName>\n" % row[0]
        xml += "  <LastName>%s</LastName>\n" % row[1]
        xml += "  <EmailAddress>%s</EmailAddress>\n" % row[2]
        xml += "  <Company>%s</Company>\n" % row[3]
        xml += "  <PhoneNumber>%s</PhoneNumber>\n" % row[4]
        xml += "  <PostalCode>%s</PostalCode>\n" % row[5]
        xml += "  <Country>%s</Country>\n" % row[6]
        xml += "  <JobFunction>%s</JobFunction>\n" % row[7]
        xml += "  <AreYouAReseller>no</AreYouAReseller>\n"
        xml += "  <InquiryType>Request Info</InquiryType>\n"
        xml += "  <EmailSubject>%s</EmailSubject>\n" % subj
        xml += "</xml>\n"
        print("TBD! email", dest, subj, xml)

def schematic(model):
        "return the path to the .sxsch file for the given model or design ID"
        try:
                # see if model is a saved design
                did = int(model)
                query = "select name, owner from designs where did=%d" % did
                rows = db_exec(query)
                if rows is None or len(rows) == 0:
                        return None
                name = rows[0][0]
                owner = int(rows[0][1])
                path = analysis.make_path(name, owner)
        except ValueError:
                path = "./models/%s.sxsch" % model
        if not os.path.isfile(path):
                return None
        return path

@get("/")
def index():
        "enter the main Angular web pages"
        return static_file("index.html", root=".")

@get("/test")
def do_test():
        "enter the API test suite"
        return static_file("test.html", root=".")

@post("/login")
def do_login():
        "login a user and create a token for them"
        result = { "success": 0, "msg": "", "token": "", "adm": 0 }
        data = request.json
        email = data["email"].lower()
        pwd = hash(data["pwd"])
        uid = check_user(email)
        if uid == 0:
                log(0, "%s not registered" % email)
                result["msg"] = "user not registered"
                return result
        if not check_pwd(uid, pwd):
                log(uid, "bad password")
                result["msg"] = "wrong credentials"
                return result
        log(uid, "login " + email)
        lead_central(uid)
        result["uid"] = uid;
        result["token"] = new_token(uid)
        result["adm"] = check_admin(uid)
        result["success"] = 1
        return result

@post("/logout")
def do_logout():
        "logout the current user and delete their token"
        result = { "success":1, "error": "" }
        uid = check_token()
        if uid != 0:
                remove_token(uid)
        return result

@post("/change")
def do_change():
        "admin function - change fields of the given user"
        result = { "success": 0, "error": "" }
        uid = check_token()
        if uid == 0:
                result["error"] = "bad token"
                return result
        args = request.json
        print("/change", args)
        try:
                req_uid = int(args["uid"])
        except:
                result["error"] = "bad request uid"
                return result        
        if not (uid == req_uid or check_admin(uid)):
                result["error"] = "no permission to make changes"
                return result
        log_msg = "change uid %d" % req_uid
        if "action" in args and args["action"] == 'delete':
                query = "delete from users where uid=%d" % req_uid
                remove_token(req_uid)
                log_msg = "delete uid %d" % req_uid
        else:
                fields = [
                        "first", "last", "email", "company", "phone",
                        "title", "country", "postal", "adm", "pwd"
                ]
                query = "update users set "
                update = False
                for key in fields:
                        if key in args:
                                if update: query += ", "
                                value = args[key]
                                if key == "pwd": value = hash(value)
                                query += "%s='%s'" % (key, value)
                                update = True
                if update:
                        query += " where uid=%d" % req_uid
                else:
                        query = ""
        if len(query) > 0:
                x = db_exec(query)
                if x is not None:
                        log(uid, log_msg)
                        result["success"] = 1
        return result

@post("/forgot")
def do_forgot():
        "user has forgotten their password, help them get logged in"
        r = { "success": 0, "error": "", "pwd": "" }
        data = request.json
        email = data["email"]
        uid = check_user(email)
        if uid == 0:
                r["error"] = "user not registered"
                return r
        # generate a new password
        pwd = secrets.token_urlsafe(8)
        # TBD: email the new password to them, if email error r["error"] = "email failure"
        # put the new password in the database as a negative number
        # this indicates a "one-time use" password
        x = -hash(pwd)
        query = "update users set pwd=%d where uid=%d" % (x, uid)
        if db_exec(query) is None:
                r["error"] = "database failure"
                return r
        r["pwd"] = pwd
        r["success"] = 1
        log(uid, "forgot password %s" % email)
        return r

@post("/newuser")
def do_new_user():
        "a new user wants to join the fun"
        r = { "success": 0, "error": "", "token": "", "uid": 0, "adm": 0 }
        data = request.json
        # if email is already there, don't put it in again
        email = data["email"].lower()
        uid = check_user(email)
        if uid != 0:
                r["uid"] = uid
                r["error"] = "user already registered"
                return r
        # put the new user into the database
        query = "insert into users "
        query += "(first,last,email,created,company,phone,title,country,postal,pwd,adm) "
        created = time.strftime("%Y-%m-%d")
        pwd = hash(data["pwd"])
        query += "values ('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s',0)" % (
                data['first'], data['last'], email, created,
                data['company'], data['phone'], data['title'], data['country'], data['postal'], pwd)
        if db_exec(query) is None:
                r["error"] = "database insert failed"
                return r
        # check the database entry was successful
        uid = check_user(email)
        if uid == 0 or not check_pwd(uid, pwd):
                log(0, "failed new user " + email)
                r["error"] = "new user not in database"
                return r
        log(uid, "new user " + email)
        lead_central(uid)
        r["uid"] = uid
        r["token"] = new_token(uid)
        r["success"] = 1
        return r

@post("/findpart")
def do_find_part():
        "build a query based on user input and return the matching list of parts"
        result = { "success": 0, "error": "", "result": [] }
        uid = check_token()
        if uid == 0:
                result["error"] = "invalid token"
                return result
        print("json", request.json)
        data = request.json
        # use airflow and maxtemp to select which fields to pull from the parts data
        tmp_index = check_maxtemp(data["maxtemp"])
        airflow = check_airflow(data["airflow"])
        # set up the parts query using the selection parameters
        query = "select ROWID,PART_NUMBER,DESIRABILITY,ANALYSIS,VIN_MIN,"
        query += "VIN_MAX,VOUT1,IOUT_MAX1,VOUT2,IOUT_MAX2,"
        query += "VOUT_MIN,VOUT_MAX,IOUT_MAX,HEIGHT,"
        query += "XDIM,YDIM,MOUNTING,PACKAGE,DATASHEET_URL,"
        query += "SIMETRIX_ANALYSIS_MODEL,SIMPLIS_ANALYSIS_MODEL,PARALLEL,DIGITAL,"
        query += "N5, IT%d_%d, NEW from parts where " % (tmp_index, airflow)
        # build the where clause
        where = [ "DESIRABILITY>0" ] # a negative DESIRABILITY indicates a discontinued part
        if data["iso"] == "isolated": where.append("ISOLATED<>'0'")
        elif data["iso"] == "non-isolated": where.append("ISOLATED='0'")
        if data["out"] == "single": where.append("DUAL='1'")
        elif data["out"] == "dual": where.append("DUAL='2'")
        x = number(data["vin"])
        if x > 0.0: where.append("VIN_MIN+0<=%f and %f<=VIN_MAX+0" % (x, x))
        x = number(data["vout"])
        if x > 0.0: where.append("VOUT_MIN+0<=%f and %f<=VOUT_MAX+0" % (x, x))
        x = number(data["iout"])
        if x > 0.0: where.append("%f<=IOUT_MAX+0" % x)
        x = number(data["vout2"])
        if x > 0.0: where.append("VOUT2+0>%f and VOUT2+0<%f" % (x-0.5,x+0.5))
        x = number(data["iout2"])
        if x > 0.0: where.append("%f<=IOUT_MAX2+0" % x)
        # not sure how to use the temp and flow parameters
        x = number(data["ht"])
        if x > 0.0: where.append("HEIGHT+0<%f" % x)
        s = data["mount"]
        if len(s) > 0 and s != "any": where.append("MOUNTING='%s'" % s)
        s = data["pkg"]
        if len(s) > 0 and s != "any": where.append("PACKAGE like '%%%s%%'" % s)
        if data["pmbus"]: where.append("DIGITAL='Y'")
        # finish off the query
        query += " and ".join(where)
        query += " order by DESIRABILITY" # this is Vesa's ranking of the parts
        # retrieve the parts
        rows = db_exec(query)
        if rows is None:
                result["error"] = "database problem"
                return result
        print(query, "yields", len(rows), "rows")
        parts = []
        for r in rows:
                obj = {
                        "row": r[0],
                        "part": r[1],
                        "rank": r[2],
                        "analysis": r[3],
                        "vinMin": number(r[4]),
                        "vinMax": number(r[5]),
                        "vout1": number(r[6]),
                        "ioutMax1": number(r[7]),
                        "vout2": number(r[8]),
                        "ioutMax2": number(r[9]),
                        "voutMin": number(r[10]),
                        "voutMax": number(r[11]),
                        "ioutMax": number(r[12]),
                        "height": number(r[13]),
                        "xdim": number(r[14]),
                        "ydim": number(r[15]),
                        "mounting": r[16],
                        "package": r[17],
                        "datasheet": r[18],
                        "simetrix": r[19],
                        "simplis": r[20],
                        "parallel": r[21],
                        "digital": r[22],
                        "eff": r[23],
                        "derate": r[24],
                        "new": r[25]
                }
                parts.append(obj)
        result["result"] = parts
        result["success"] = 1
        return result

def check_airflow(airflow):
        "return a valid airflow (0, 100, ...) so we pick up the right database column"
        if not airflow: return 200
        try:
                airflow = float(airflow)
        except ValueError:
                return 200
        if airflow <= 0: return 0
        elif airflow <= 100: return 100
        elif airflow <= 200: return 200
        elif airflow <= 300: return 300
        return 400

def check_maxtemp(temp):
        "return an index to the temperature derating data in the database"
        if not temp: return 0
        try:
                temp = float(temp)
        except ValueError:
                temp = 25
        if temp <= 50: return 1
        elif temp <= 65: return 2
        elif temp <= 75: return 3
        elif temp <= 80: return 4
        else: return 5

def number(s):
        "return a floating point number, return 0.0 if input is not a number"
        try:
                return float(s)
        except ValueError:
                return 0.0

@post("/eff")
def do_efficiency():
        "return the efficiency data for the requested part rowid"
        r = {
                "success": 0,
                "error": "",
                "part": "",
                "axis": {
                        "x": "Current (A)",
                        "y": "Efficiency (%)"
                },
                "vin": 0,
                "vout": 0,
                "x": [],
                "y": []
        }
        print("efficiency", request.json)
        if check_token() == 0:
                r["error"] = "invalid token"
                return r
        try:
                rowid = int(request.json["row"])
        except:
                r["error"] = "row is not a number"
                return r
        query = "select IN1,IN2,IN3,IN4,IN5,N1,N2,N3,N4,N5,"
        query += "PART_NUMBER,VIN_TEST,VOUT_TEST from parts "
        query += "where ROWID=%d" % rowid
        rows = db_exec(query)
        if rows is None or len(rows) == 0:
                r["error"] = "part (%d) not in database" % rowid
        else:
                row = rows[0]
                r["x"] = row[0:5]
                r["y"] = row[5:10]
                r["part"] = row[10]
                r["vin"] = row[11]
                r["vout"] = row[12]
                r["success"] = 1
        return r

@post("/thermal")
def do_thermal():
        "return the airflow data for the requested part rowid"
        r = {
                "success": 0,
                "error": "",
                "part": "",
                "axis": {
                        "x": "Temperature (C)",
                        "y0": "Current (A) at 0 LFM",
                        "y100": "Current (A) at 100 LFM",
                        "y200": "Current (A) at 200 LFM",
                        "y300": "Current (A) at 300 LFM",
                        "y400": "Current (A) at 400 LFM"
                },
                "vin": 0,
                "vout": 0,
                "x": [],
                "y0": [],
                "y100": [],
                "y200": [],
                "y300": [],
                "y400": []
        }
        if check_token () == 0:
                r["error"] = "invalid token"
                return r
        try:
                rowid = int(request.json["row"])
        except:
                r["error"] = "row is not a number"
                return r
        query = "select T1_0, T2_0, T3_0, T4_0, T5_0, "
        query += "IT1_0, IT2_0, IT3_0, IT4_0, IT5_0, "
        query += "IT1_100, IT2_100, IT3_100, IT4_100, IT5_100, "
        query += "IT1_200, IT2_200, IT3_200, IT4_200, IT5_200, "
        query += "IT1_300, IT2_300, IT3_300, IT4_300, IT5_300, "
        query += "IT1_400, IT2_400, IT3_400, IT4_400, IT5_400, "
        query += "PART_NUMBER,VIN_TEST,VOUT_TEST from parts "
        query += "where ROWID=%d" % rowid
        rows = db_exec(query)
        if rows is None or len(rows) == 0:
                r["error"] = "part (%d) not found" % rowid
        else:
                row = rows[0]
                r["x"] = row[0:5]
                r["y0"] = row[5:10]
                r["y100"] = row[10:15]
                r["y200"] = row[15:20]
                r["y300"] = row[20:25]
                r["y400"] = row[25:30]
                r["part"] = row[30]
                r["vin"] = row[31]
                r["vout"] = row[32]
                r["success"] = 1
        return r

@post("/tune-loop")
def do_tune_loop():
        "perform the tunable loop calculation"
        if check_token() == 0:
                return { "success": 0, "error": "invalid token" }
        d = request.json
        r = tl.calc(d["part"], float(d["vin"]), float(d["vout"]),
                           float(d["dImax"]), d["dVmax"])
        # print("/tune-loop", d, "returns", r)
        return r

@post("/pol-volt")
def do_pol_volt():
        "perform the POL voltage tolerance calculation"
        if check_token() == 0:
                return { "success": 0, "error": "invalid token" }
        d = request.json
        r = pol.volt(d["part"], d["vout"], d["rg"], d["volow"], d["vohigh"])
        # print("/pol-volt", d, "returns", r)
        return r

@post("/pol-trim")
def do_pol_trim():
        "perform the POL trim resistance calculation"
        if check_token() == 0:
                return { "success": 0, "error": "invalid token" }
        d = request.json
        r = pol.trim(d["part"], d["vout"], d["margin"])
        # print("/pol-trim", d, "returns", r)
        return r

@post("/pol-vset")
def do_pol_vset():
        "perform the POL voltage setting calculation"
        if check_token() == 0:
                return { "success": 0, "error": "invalid token" }
        d = request.json
        r = pol.vset(d["part"], d["vout"], d["rtrim"], d["rup"], d["rdown"], d["tol"])
        return r

@post("/sim-init")
def do_sim_init():
        "gather the schematic and BOM for the given model"
        r = { "success": 0, "error": "" }
        uid = check_token()
        arg_bad = check_args("model")
        if uid == 0 or arg_bad:
                r["error"] = "bad token" if uid == 0 else arg_bad
        else:
                model = request.json["model"]
                path = schematic(model)
                r = analysis.init(path)
                if r["success"] == 1:
                        log(uid, "sim init %s" % model)
        return r

@post("/sim-run")
def do_sim_run():
        "run the simulation and get the raw data"
        r = { "success": 0, "error": "" }
        uid = check_token()
        arg_bad = check_args("model", "bom")
        if uid == 0 or arg_bad:
                r["error"] = "bad token" if uid == 0 else arg_bad
        else:
                model = request.json["model"]
                bom = request.json["bom"]
                path = schematic(model)
                r = analysis.run(path, bom)
                if r["success"] == 1:
                        log(uid, "sim run %s" % model)
        return r

@post("/sim-save")
def do_sim_save():
        "save a design for the user"
        r = { "success": 0, "error": ""}
        uid = check_token()
        arg_bad = check_args("model", "bom", "name", "desc")
        if uid == 0 or arg_bad:
                r["error"] = "bad token" if uid == 0 else arg_bad
        else:
                model = request.json["model"]
                src = schematic(model)
                bom = request.json["bom"]
                name = request.json["name"]
                desc = request.json["desc"]
                # generate the design file using Simplis
                r = analysis.save(src, bom, name, uid)
        # if successful, put the design into the database
        if r["success"] == 1:
                log(uid, "sim save %s to %s" % (model, name))
                ts = time.time() 
                query = "insert into designs (name,desc,owner,public,updated) "
                query += "values ('%s','%s',%d,0,%d)" % (name, desc, uid, ts)
                if db_exec(query) is None:
                        r["error"] = "database error"
                        r["success"] = 0
        return r

@post("/design-list")
def do_design_list():
        "generate a list of designs the user can access"
        r = { "success": 0, "error": "", "designs": [] }
        uid = check_token()
        if uid == 0:
                r["error"] = "bad token"
                return r
        query = "select did,name,desc,owner,shared,public,updated from designs "
        query += "where owner=%d or shared like '%%:%d:%%' " % (uid, uid)
        query += "or public=1 order by name"
        rows = db_exec(query)
        if rows is None:
                r["error"] = "database error"
                return r
        data = []
        for row in rows:
                print(row)
                dt = time.localtime(float(row[6]))
                item = { "did": int(row[0]),
                        "name": row[1],
                        "desc": row[2],
                        "owner": username(row[3]),
                        "shared": 1 if row[4] else 0,
                        "public": 1 if row[5] else 0,
                        "updated": time.strftime("%Y-%m-%d %H:%M:%S", dt)
                }
                data.append(item)
        r["designs"] = data
        r["success"] = 1
        return r

@post("/design-public")
def do_design_public():
        "an admin user can make a design public or private"
        r = { "success": 0, "error": "" }
        uid = check_token()
        if uid == 0:
                r["error"] = "bad token"
                return r
        is_adm = check_admin(uid)
        if not is_adm:
                r["error"] = "not an admin user"
                return r
        arg_bad = check_args("did", "state")
        if arg_bad :
                r["error"] = arg_bad
                return r
        did = int(request.json["did"])
        state = 1 if request.json["state"] else 0
        query = "update designs set public=%d where did=%d" % (state, did)
        if db_exec(query) is None:
                r["error"] = "database could not be updated"
                return r
        r["success"] = 1
        return r

@post("/design-del")
def do_design_del():
        "owner deletes the design, others remove themselves from sharing"
        r = { "success": 0, "error": "" }
        uid = check_token()
        arg_bad = check_args("did")
        if uid == 0 or arg_bad:
                r["error"] = "bad token" if uid == 0 else arg_bad
                return r
        did = int(request.json["did"])
        query = "select name,owner,shared from designs where did=%d" % did
        rows = db_exec(query)
        if rows is None or len(rows) == 0:
                r["error"] = "cannot delete this design"
                return r
        row = rows[0]
        name = row[0]
        owner = int(row[1])
        shared = unpack(row[2])
        print("shared", shared)
        if uid == owner:
                query = "delete from designs where did=%d" % did
                analysis.delete(name, uid) # completely delete the file
                log_msg = "design %s (%d) deleted" % (name, did)
        elif str(uid) in shared:
                shared.remove(str(uid))
                query = "update designs set shared='%s' where did=%d" % (pack(shared), did)
                log_msg = "design %d unshared by %d" % (did, uid)
        else:
                r["error"] = "no permitted to change the design"
                return r
        if db_exec(query) is None:
                r["error"] = "database error"
                return r
        log(uid, log_msg)
        r["success"] = 1
        return r

@post("/design-share")
def do_design_share():
        "share a design with another PMW user (email)"
        r = { "success": 0, "error": "" }
        uid = check_token()
        arg_bad = check_args("did", "emails")
        if uid == 0 or arg_bad:
                r["error"] = "bad token" if uid == 0 else arg_bad
                return r
        # make sure the design exists and the user owns it
        did = int(request.json["did"])
        query = "select name,desc,owner,shared from designs where did=%d" % did
        rows = db_exec(query)
        if rows is None or len(rows) != 1:
                r["error"] = "design %d not in database" % did
                return r
        owner = int(rows[0][2])
        if owner != uid:
                r["error"] = "not an owner of this design"
                return r
        # add on the additional users
        shared = unpack(rows[0][3])                
        emails = request.json["emails"]
        for email in emails:
                share_uid = check_user(email)
                if share_uid == 0:
                        r["error"] = "'%s' is not a PMW user" % email
                        return r
                shared.append(str(share_uid))
        query = "update designs set shared='%s' where did=%d" % (pack(shared), did)
        if db_exec(query) is None:
                r["error"] = "database error updating shared design"
                return r
        log(uid, "design %d shared with %s" % (did, email))
        r["success"] = 1
        return r

@post("/design-upload")
def do_design_upload():
        "upload a users design and store it in the proper place"
        r = { "success": 0, "error": "" }
        uid = check_token()
        arg_bad = check_args("name", "desc", "file")
        if uid == 0 or arg_bad:
                r["error"] = "bad token" if uid == 0 else arg_bad
                return r
        name = request.json["name"]
        desc = request.json["desc"]
        file = request.json["file"]
        print("upload", name, desc, len(file), "bytes")
        if not analysis.upload(name, uid, file):
                r["error"] = "failed to save file"
                return r
        query = "insert into designs (name,desc,owner,updated) values "
        query += "('%s','%s',%d,%d)" % (name, desc, uid, time.time())
        if db_exec(query) is None:
                r["error"] = "database insert error"
                return r
        r["success"] = 1
        return r

@get("/des-down/<did>")
def do_des_down(did=None):
        if did is None:
                response.status = 400
                return ""
        else:
                query = "select name, owner from designs where did=%d" % int(did)
                rows = db_exec(query)
                if rows is None:
                        response.status = 404
                        return ""
                name = rows[0][0]
                owner = int(rows[0][1])
                content = analysis.download(name, owner)
                print("/des-down", content)
                return content
        
                        
@post("/design-download")
def do_design_download():
        "arrange for the browser to download the given design"
        r = { "success": 0, "error": "" }
        uid = check_token()
        bad_arg = check_args("did")
        if uid == 0 or bad_arg:
                r["error"] = "bad token" if uid == 0 else bad_arg
                return r
        did = int(request.json["did"])
        query = "select name, owner from designs where did=%d" % did
        rows = db_exec(query)
        if rows is None:
                r["error"] = "no design specified"
                return r
        name = rows[0][0]
        owner = int(rows[0][1])
        content = analysis.download(name, owner)
        if content is None:
                r["error"] = "could not retrieve file"
                return r
        # we have the file, ask the browser to save it
        response.set_header("Content-Disposition", "attachment")
        response.set_header("Content-type", "application/octet-stream")
        return content
        
@post("/users")
def do_users():
        "admin function - get info about users"
        r = { "success": 0, "error": "", "result": [] }
        if check_token() == 0:
                r["error"] = "invalid token"
                return r
        data = request.json
        uid = number(data["uid"])
        query = "select uid,first,last,email,created,company,phone,title,country,postal,adm from users "
        if uid > 0:
                query += " where uid=%d " % uid
        query += "order by uid "
        rows = db_exec(query)
        if rows is None:
                r["error"] = "database query problem"
                return r
        userdata = []
        for row in rows:
                obj = {
                        "uid": row[0],
                        "first": row[1],
                        "last": row[2],
                        "email": row[3],
			"created": row[4],
                        "company": row[5],
                        "phone": row[6],
			"title": row[7],
                        "country": row[8],
                        "postal": row[9],
                        "adm": row[10]
                }
                userdata.append(obj)
        if len(userdata) == 0 and uid > 0:
                r["error"] = "uid %d not found" % uid
                return r
        r["result"] = userdata
        r["success"] = 1
        return r

@post("/log")
def do_log():
        "admin function - get info from the logs"
        r = { "success": 0, "error": "", "result": [] }
        uid = check_token()
        if uid == 0:
                r["error"] = "invalid token"
                return r
        action = request.json["action"]
        if action == "clear":
                x = db_exec("delete from log")
                if x is None:
                        r["error"] = "database delete failed"
                        return r
                r["success"] = 1
                log(uid, "log cleared")
                return r
        query = "select uid,event,ts from log where 1 "
        s = request.json["filter"]
        if len(s) > 0:
                query += "and event like '%%%s%%' " % s
        s = request.json["date"]
        if len(s) > 0:
                start = time.mktime(time.strptime(s, "%Y-%m-%d"))
                query += "and ts > %d " % start
        query += "order by ts"
        rows = db_exec(query)
        if rows is None:
                r["error"] = "database failure"
                return r
        logdata = []
        for row in rows:
                dt = time.localtime(float(row[2]))                
                obj = { "uid": row[0], "event": row[1], "when": time.strftime("%Y-%m-%d %H:%M:%S", dt) }
                logdata.append(obj)
        r["result"] = logdata
        r["success"] = 1
        return r

partFields = [ 
	"PART_NUMBER", "ISOLATED", "PARALLEL", "DIGITAL", "DUAL",
        "ANALYSIS", "NEW", "DESIRABILITY", "TYPE",
        "VIN_MIN", "VIN_MAX", "VOUT1", "IOUT_MAX1", "VOUT2", "IOUT_MAX2",
	"VOUT_MIN", "VOUT_MAX", "IOUT_MAX", "VIN_TEST", "VOUT_TEST",
	"MOUNTING", "HEIGHT", "XDIM", "YDIM", "DOSA", "PACKAGE",
        "DATASHEET_URL", "SIMETRIX_ANALYSIS_MODEL", "SIMPLIS_ANALYSIS_MODEL",
	"IN1", "N1", "IN2", "N2", "IN3", "N3", "IN4", "N4", "IN5", "N5",
	"T1_0", "IT1_0", "T2_0", "IT2_0", "T3_0", "IT3_0", "T4_0", "IT4_0", "T5_0", "IT5_0",
	"T1_100", "IT1_100", "T2_100", "IT2_100", "T3_100", "IT3_100", "T4_100", "IT4_100", "T5_100", "IT5_100",
	"T1_200", "IT1_200", "T2_200", "IT2_200", "T3_200", "IT3_200", "T4_200", "IT4_200", "T5_200", "IT5_200",
	"T1_300", "IT1_300", "T2_300", "IT2_300", "T3_300", "IT3_300", "T4_300", "IT4_300", "T5_300", "IT5_300",
	"T1_400", "IT1_400", "T2_400", "IT2_400", "T3_400", "IT3_400", "T4_400", "IT4_400", "T5_400", "IT5_400",
]

@post("/listparts")
def do_list_parts():
        "return a list of parts in the database for use in a HTML <select>"
        r = { "success": 0, "error": "", "results": [] }
        uid = check_token()
        if uid == 0 or check_admin(uid) == 0:
                r["error"] = "not authorized"
                return r
        query = "select ROWID,PART_NUMBER,VIN_TEST,VOUT_TEST,DESIRABILITY from parts order by PART_NUMBER"
        rows = db_exec(query)
        if rows is None:
                r["error"] = "database failure"
                return r
        data = []
        for row in rows:
                obj = { "ROWID": row[0], "PART_NUMBER": row[1],
                        "VIN_TEST": row[2], "VOUT_TEST": row[3],
                        "DESIRABILITY": row[4] }
                data.append(obj)
        r["success"] = 1
        r["results"] = data
        return r

@post("/getpart")
def do_get_part():
        "get all the details for the specified part rowid"
        r = { "success": 0, "error": "" }
        uid = check_token()
        if uid == 0 or check_admin(uid) == 0:
                r["error"] = "not authorized"
                return r
        try:
                rowid = int(request.json["rowid"])
        except:
                r["error"] = "bad arguments"
                return r
        query = "select " + ",".join(partFields) + " from parts where ROWID=%d" % rowid
        rows = db_exec(query)
        if rows is None or len(rows) == 0:
                r["error"] = "database failure"
                return r
        row = rows[0]
        for i in range(len(partFields)):
                field = partFields[i]
                r[field] = row[i]
        r["success"] = 1
        return r

@post("/setpart")
def do_set_part():
        "modify the specified part rowid with field updates"
        r = { "success": 0, "error": "" }
        uid = check_token()
        if uid == 0 or check_admin(uid) == 0:
                r["error"] = "not authorized"
                return r
        try:
                rowid = int(request.json["rowid"])
        except:
                r["error"] = "bad arguments"
                return r
        data = request.json
        updates = []
        for field in partFields:
                if field in data:
                        item = "%s='%s'" % (field, data[field])
                        updates.append(item)
        if len(updates) > 0:
                query = "update parts set %s where ROWID=%d" % (",".join(updates), rowid)
                rows = db_exec(query)
                if rows is None:
                        r["error"] = "update failed"
                        return r
        r["success"] = 1
        return r

@post("/newpart")
def do_new_part():
        "enter a new part into the part database"
        r = { "success": 0, "error": "" }
        uid = check_token()
        if uid == 0 or not check_admin(uid):
                r["error"] = "not authorized"
                return r
        values = []
        data = request.json
        for field in partFields:
                item = data[field] if field in data else ""
                if isinstance(item, str): item = "'%s'" % item
                values.append(item)
        query = "insert into parts (%s) values (%s)" % (",".join(partFields), ",".join(values))
        # print(query)
        if db_exec(query) is None:
                r["error"] = "database insert failed"
        else:
                r["success"] = 1
        return r                                       

@post("/feedback")
def do_feedback():
        "allow user to submit feedback about Power Module Wizard"
        r = { "success": 1, "error": "" }
        print("TBD: send feedback email somewhere",
              request.json["type"], request.json["comment"])
        return r

@post("/contact-list")
def do_contact_list():
        "retrieve the contact list for the user; they always have the FAE"
        r = { "success": 0, "error": "", "contacts": None }
        uid = check_token()
        if uid == 0:
                r["error"] = "bad token"
                return r
        query = "select email from contacts where uid=%d order by email" % uid
        rows = db_exec(query)
        contacts = [ "dl-techsupport@omnionpower.com" ]
        for row in rows:
                contacts.append(str(row[0]).lower())
        r["contacts"] = contacts
        r["success"] = 1
        return r

@post("/contact-add")
def do_contact_add():
        "add an email to a user's contact list"
        r = { "success": 0, "error": "" }
        uid = check_token()
        bad_arg = check_args("emails")
        if uid == 0 or bad_arg:
                r["error"] = "bad token" if uid == 0 else bad_arg
                return r
        emails = request.json["emails"]
        for email in emails:
                email = email.lower()
                # check if it's already there
                query = "select email from contacts where uid=%d and email='%s'" % (uid, email)
                rows = db_exec(query)
                if len(rows) > 0:
                        r["error"] = "'%s' already a contact" % email
                        return r
                query = "insert into contacts (uid, email) values (%d, '%s')" % (uid, email)
                if db_exec(query) is None:
                        r["error"] = "database error"
                        return r
        r["success"] = 1
        return r

@post("/contact-del")
def do_contact_del():
        "delete a contact from a user's contact list"
        r = { "success": 0, "error": "" }
        uid = check_token()
        bad_arg = check_args("email")
        if uid == 0 or bad_arg:
                r["error"] = "bad token" if uid == 0 else bad_arg
                return r
        email = request.json["email"]
        query = "delete from contacts where uid=%d and email='%s'" % (uid, email)
        if db_exec(query) is None:
                r["error"] = "database problem"
                return r
        r["success"] = 1
        return r

# main routine, start up the server

if len(sys.argv) > 1 and sys.argv[1] == 'PROD':
    db = sqlite3.connect("pmw.db")
    try:
        load_dotenv(".env")
        run(host=os.getenv('apphost'), port=int(os.getenv('appport')), debug=False, reloader=False)
    except:
        # Fall back to Rob's local
        run(host="10.0.30.25", port=8997, debug=False, reloader=False)
else:
    db = sqlite3.connect("pmw.db")
    run(host="localhost", port=8080, debug=True, reloader=True)

