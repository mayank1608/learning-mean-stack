# generate a parts table out of pol.xlsx
# save results in pol_data.py

import openpyxl

src = "C:\\pmw\\pol.xlsx"
outfile = open("pol_data.py", 'w')

def ascii(s):
    r = ""
    if s is None: return ""
    for i in range(len(s)):
        ch = ord(s[i])
        if ch < 256:
            r += s[i]
        elif ch == 8482:
            r += "(tm)"
        else:
            print("found %d in %s at %d" % (ch, s, i))
            r += "?"
    return r

def put(s):
    # print(s)
    outfile.write(s + "\n")

put('''
class Part:
    def __init__(self, name, num, r1, r2, vref, vreftol, ruptol, tvomax):
        self.name = name
        self.num = num
        self.r1 = r1
        self.r2 = r2
        self.vref = vref
        self.vreftol = vreftol
        self.ruptol = ruptol
        self.tvomax = tvomax

    def vomax(self, E50, E51, C52, E53):
        if self.tvomax == 0:
            return E50*((E51+C52)/C52)+E53
        elif self.tvomax == 1:
            return (1.005*E50*((E51+C52)/C52))+E53
        else:
            return E50+0.0005

    def vomin(self, C50, E52, C51, C53):
        if self.tvomax == 0:
            return C50*((E52+C51)/E52)+C53
        elif self.tvomax == 1:
            return (0.995*C50*((E52+C51)/E52))+C53
        else:
            return C50-0.005

    def fixTJT(self, C24):
        if self.tvomax == 2:
            self.vref = C25
            self.r1 = tjt_lookup(C24)

''')

wb = openpyxl.load_workbook(filename=src)
ws = wb.active

put("parts = [")
for row in range(58, 107):
    r = str(row)
    name = ascii(ws["M"+r].value)
    num = (row - 58) + 1 # ws["N"+r].value was a formula, yuk
    r1 = ws["O"+r].value
    r2 = ws["P"+r].value
    vref = ws["Q"+r].value
    vreftol = ws["R"+r].value
    ruptol = ws["S"+r].value
    # U contains formulas classified as type 0, 1, or 2 (see spreadsheet)
    x = ws["U"+r].value
    if "1.005" in x:
        tvomax = 1
    elif "0.005" in x:
        tvomax = 2
    else:
        tvomax = 0
    # excise formulas from the TJT types
    if tvomax == 2:
        r1 = 0
        vref = 0
    # print(name, num, r1, r2, vref, vreftol, ruptol, tvomax)
    x = "  Part('%s', %d, %d, %d, %f, %f, %f, %d)," % \
        (name, num, r1, r2, vref, vreftol, ruptol, tvomax)
    put(x)
put("]")
put("")
put("def tjt_lookup(x):")

for row in range(114, 185):
    r = str(row)
    volts = ws["N"+r].value
    ohms = ws["O"+r].value
    put("    if x <= %f: return %d" % (volts, ohms))
put("    return %d" % ohms)
put('''
if __name__ == "__main__":
    print(len(parts), "parts")
    p = parts[0]
    print(p.name, p.num, p.tvomax)
    print("tjt_lookup(0.5)", tjt_lookup(0.5))
''')

outfile.close()
